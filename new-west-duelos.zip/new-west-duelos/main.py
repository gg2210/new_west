import os
import pygame
import random
import json
import sys
from typing import Dict

# Inicialização
pygame.init()
pygame.mixer.init()

# Configurações (aumentei o tamanho da tela)
SCREEN_WIDTH, SCREEN_HEIGHT = 1024, 768
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SCALED)
pygame.display.set_caption("Duelo no Oeste: Showdown")
clock = pygame.time.Clock()
FPS = 60

# Constantes
ASSETS_DIR = "assets"
SPRITE_SIZE = (150, 150)
BULLET_SIZE = (30, 10)
BASE_BULLET_SPEED = 25
CHAO_Y = SCREEN_HEIGHT * 0.90  # 90% da tela (personagens mais para baixo)
MAX_ROUNDS = 10

# Cores
WHITE = (255, 255, 255)
RED = (200, 50, 50)
BLUE = (50, 50, 200)
GOLD = (255, 215, 0)
GREEN = (50, 200, 50)
BROWN = (139, 69, 19)
BLACK_ALPHA = (0, 0, 0, 180)  # Preto com transparência

class AssetManager:
    @staticmethod
    def load_assets() -> Dict[str, any]:
        """Carrega todos os assets organizados por pastas"""
        assets = {
            # Imagens
            "bg_menu": AssetManager._load_image("menu_bg.jpg", "backgrounds"),
            "bg_game": AssetManager._load_image("game_bg.jpg", "backgrounds"),

            # Sprites
            "player1": {
                "idle": AssetManager._load_image("cowboy_idle.png", "sprites"),
                "shoot": AssetManager._load_image("cowboy_shoot.png", "sprites"),
                "dead": AssetManager._load_image("cowboy_dead.png", "sprites")
            },
            "player2": {
                "idle": AssetManager._load_image("enemy_idle.png", "sprites"),
                "shoot": AssetManager._load_image("enemy_shoot.png", "sprites"),
                "dead": AssetManager._load_image("enemy_dead.png", "sprites")
            },

            # Sons
            "sounds": {
                "shot": AssetManager._load_sound("shot.wav"),
                "win": AssetManager._load_sound("win.wav"),
                "lose": AssetManager._load_sound("lose.wav"),
                "click": AssetManager._load_sound("click.wav"),
                "achievement": AssetManager._load_sound("achievement.wav")
            },
            "music": {
                "duel": AssetManager._load_music("duel.mp3"),
                "achievements": AssetManager._load_music("achievements.mp3"),
                "training": AssetManager._load_music("training.mp3")
            },

            # UI
            "bullet": AssetManager._load_image("bullet.png", "ui")
        }
        return assets

    @staticmethod
    def _load_image(filename: str, subfolder: str) -> pygame.Surface:
        """Carrega imagem com fallback"""
        try:
            path = os.path.join(ASSETS_DIR, "images", subfolder, filename)
            img = pygame.image.load(path).convert_alpha()
            return pygame.transform.scale(img, (SPRITE_SIZE if subfolder == "sprites" 
                                             else BULLET_SIZE if filename == "bullet.png"
                                             else (SCREEN_WIDTH, SCREEN_HEIGHT)))
        except:
            surf = pygame.Surface((SPRITE_SIZE if subfolder == "sprites" 
                                 else BULLET_SIZE if filename == "bullet.png"
                                 else (SCREEN_WIDTH, SCREEN_HEIGHT)), pygame.SRCALPHA)
            surf.fill(RED if "cowboy" in filename else BLUE if "enemy" in filename else WHITE)
            return surf

    @staticmethod
    def _load_sound(filename: str) -> pygame.mixer.Sound:
        """Carrega efeitos sonoros com fallback silencioso"""
        try:
            path = os.path.join(ASSETS_DIR, "sounds", filename)
            sound = pygame.mixer.Sound(path)
            sound.set_volume(0.7)
            return sound
        except:
            return pygame.mixer.Sound(buffer=bytes([0]*1000))

    @staticmethod
    def _load_music(filename: str) -> str:
        """Retorna caminho da música"""
        path = os.path.join(ASSETS_DIR, "music", filename)
        return path if os.path.exists(path) else ""

class Game:
    def __init__(self):
        self.assets = AssetManager.load_assets()
        self.font_large = pygame.font.Font(None, 72)
        self.font_medium = pygame.font.Font(None, 48)
        self.font_small = pygame.font.Font(None, 36)

        # Estado do jogo
        self.reset_game_state()
        self.setup_controls()

        # Conquistas
        self.achievements = {
            "round_5": False,
            "round_10": False,
            "fast_winner": False,
            "perfect_10": False,
            "no_miss": False,
            "first_blood": False,
            "pvp_winner": False,
            "training_master": False
        }
        self.load_achievements()

        # Música
        self.music_volume = 0.5
        self.current_music = ""

    def reset_game_state(self):
        """Reseta todo o estado do jogo"""
        self.game_mode = None  # 'arcade', 'pvp', 'training'
        self.game_state = "menu"
        self.arcade_score = 0
        self.arcade_round = 1
        self.arcade_wins = 0
        self.pvp_score = [0, 0]  # [player1, player2]
        self.reset_duel_state()

    def reset_duel_state(self):
        """Reseta o estado do duelo atual"""
        self.player1_state = "idle"
        self.player2_state = "idle"
        # Posições ajustadas para o novo tamanho da tela
        self.player1_pos = [SCREEN_WIDTH*0.2, CHAO_Y - SPRITE_SIZE[1]]
        self.player2_pos = [SCREEN_WIDTH*0.8 - SPRITE_SIZE[0], CHAO_Y - SPRITE_SIZE[1]]
        self.bullets = []
        self.last_shot = 0
        self.winner = None
        self.duel_start_time = 0
        self.shots_fired = 0
        self.shots_hit = 0
        self.training_hits = 0
        self.training_misses = 0

    def setup_controls(self):
        """Configura controles touch"""
        self.controls = {
            # Menu
            "arcade": pygame.Rect(SCREEN_WIDTH//2 - 150, 300, 300, 80),
            "pvp": pygame.Rect(SCREEN_WIDTH//2 - 150, 400, 300, 80),
            "training": pygame.Rect(SCREEN_WIDTH//2 - 150, 500, 300, 80),
            "achievements": pygame.Rect(SCREEN_WIDTH//2 - 150, 600, 300, 80),

            # Duelo
            "shoot_left": pygame.Rect(50, SCREEN_HEIGHT-150, 200, 150),
            "shoot_right": pygame.Rect(SCREEN_WIDTH-250, SCREEN_HEIGHT-150, 200, 150),

            # Treino
            "training_target": pygame.Rect(SCREEN_WIDTH//2 - 50, CHAO_Y - 150, 100, 100)
        }

    # --- Sistema de Áudio ---
    def play_music(self, track: str):
        """Toca uma música específica"""
        if track in self.assets["music"] and self.assets["music"][track]:
            if self.current_music != track:
                pygame.mixer.music.stop()
                pygame.mixer.music.load(self.assets["music"][track])
                pygame.mixer.music.set_volume(self.music_volume)
                pygame.mixer.music.play(-1)
                self.current_music = track

    def stop_music(self):
        """Para a música atual"""
        pygame.mixer.music.stop()
        self.current_music = ""

    def play_sound(self, sound: str):
        """Toca um efeito sonoro"""
        if sound in self.assets["sounds"]:
            self.assets["sounds"][sound].play()

    # --- Lógica do Jogo ---
    def start_arcade_mode(self):
        """Inicia o modo arcade com 10 rodadas"""
        self.reset_game_state()
        self.game_mode = "arcade"
        self.start_duel()

    def start_pvp_mode(self):
        """Inicia o modo Player vs Player"""
        self.reset_game_state()
        self.game_mode = "pvp"
        self.start_duel()

    def start_training_mode(self):
        """Inicia o modo de treino"""
        self.reset_game_state()
        self.game_mode = "training"
        self.game_state = "training"
        self.play_music("training")
        self.play_sound("click")

    def start_duel(self):
        """Inicia um novo duelo"""
        self.reset_duel_state()
        self.game_state = "countdown"
        self.countdown = 3
        self.countdown_start = pygame.time.get_ticks()
        self.play_music("duel")
        self.play_sound("click")

    def calculate_difficulty(self) -> float:
        """Retorna multiplicador de dificuldade (1.0 a 3.0)"""
        if self.game_mode == "arcade":
            return min(3.0, 1.0 + (self.arcade_round * 0.2))
        return 1.0  # Modo PvP e treino não têm aumento de dificuldade

    def fire_shot(self, player: int):
        """Dispara um tiro com cooldown"""
        now = pygame.time.get_ticks()
        if now - self.last_shot < 300:  # Cooldown de 300ms
            return

        self.last_shot = now
        self.shots_fired += 1
        speed = BASE_BULLET_SPEED * self.calculate_difficulty()

        if player == 1:
            self.bullets.append({
                "x": self.player1_pos[0] + SPRITE_SIZE[0],
                "y": self.player1_pos[1] + SPRITE_SIZE[1]//2,
                "speed": speed,
                "player": 1
            })
            self.player1_state = "shoot"
        else:
            self.bullets.append({
                "x": self.player2_pos[0],
                "y": self.player2_pos[1] + SPRITE_SIZE[1]//2,
                "speed": -speed,
                "player": 2
            })
            self.player2_state = "shoot"

        self.play_sound("shot")

    def fire_training_shot(self):
        """Dispara um tiro no modo treino"""
        now = pygame.time.get_ticks()
        if now - self.last_shot < 300:  # Cooldown de 300ms
            return

        self.last_shot = now
        self.shots_fired += 1

        self.bullets.append({
            "x": self.player1_pos[0] + SPRITE_SIZE[0],
            "y": self.player1_pos[1] + SPRITE_SIZE[1]//2,
            "speed": BASE_BULLET_SPEED,
            "player": 1
        })
        self.player1_state = "shoot"
        self.play_sound("shot")

    def update(self):
        """Atualiza a lógica do jogo"""
        now = pygame.time.get_ticks()

        # Contagem regressiva
        if self.game_state == "countdown":
            elapsed = now - self.countdown_start
            self.countdown = max(0, 3 - int(elapsed / 1000))

            if elapsed >= 3000:
                self.game_state = "duel"
                self.duel_start_time = now
                self.play_sound("click")

        # Durante o duelo
        elif self.game_state == "duel":
            # Atualiza balas
            for bullet in self.bullets[:]:
                bullet["x"] += bullet["speed"]

                # Verifica colisões
                if bullet["player"] == 1 and bullet["x"] > self.player2_pos[0]:
                    self.player2_state = "dead"
                    self.winner = 1
                    self.shots_hit += 1
                    self.end_duel()
                elif bullet["player"] == 2 and bullet["x"] < self.player1_pos[0] + SPRITE_SIZE[0]:
                    self.player1_state = "dead"
                    self.winner = 2
                    self.end_duel()

                # Remove balas fora da tela
                if bullet["x"] < 0 or bullet["x"] > SCREEN_WIDTH:
                    self.bullets.remove(bullet)

            # Reseta animação de tiro
            if now - self.last_shot > 200:
                if self.player1_state != "dead":
                    self.player1_state = "idle"
                if self.player2_state != "dead":
                    self.player2_state = "idle"

            # IA no modo arcade
            if self.game_mode == "arcade" and random.random() < 0.01 * self.calculate_difficulty():
                self.fire_shot(2)

        # Modo treino
        elif self.game_state == "training":
            # Atualiza balas no modo treino
            for bullet in self.bullets[:]:
                bullet["x"] += bullet["speed"]

                # Verifica se acertou o alvo
                target_rect = self.controls["training_target"]
                if (bullet["x"] > target_rect.left and bullet["x"] < target_rect.right and
                    bullet["y"] > target_rect.top and bullet["y"] < target_rect.bottom):
                    self.training_hits += 1
                    self.bullets.remove(bullet)
                    self.play_sound("win")
                    # Move o alvo para uma nova posição aleatória
                    self.controls["training_target"].x = random.randint(100, SCREEN_WIDTH - 200)
                    self.controls["training_target"].y = random.randint(100, CHAO_Y - 200)
                elif bullet["x"] > SCREEN_WIDTH:  # Remove balas que saíram da tela
                    self.training_misses += 1
                    self.bullets.remove(bullet)

            # Reseta animação de tiro
            if now - self.last_shot > 200 and self.player1_state != "idle":
                self.player1_state = "idle"

    def end_duel(self):
        """Finaliza o duelo atual"""
        self.game_state = "result"

        if self.winner == 1:
            self.play_sound("win")
            if self.game_mode == "arcade":
                self.arcade_wins += 1
                self.check_achievements()
            elif self.game_mode == "pvp":
                self.pvp_score[0] += 1
                if self.pvp_score[0] >= 5:  # Melhor de 5
                    self.unlock_achievement("pvp_winner")
        else:
            self.play_sound("lose")
            if self.game_mode == "pvp":
                self.pvp_score[1] += 1

    def handle_round_transition(self):
        """Gerencia transição entre rodadas"""
        if self.game_mode == "arcade":
            if self.winner == 1:
                self.arcade_round += 1
                if self.arcade_round <= MAX_ROUNDS:
                    self.start_duel()
                else:
                    self.stop_music()
                    self.game_state = "menu"
            else:
                self.start_duel()
        elif self.game_mode == "pvp":
            if max(self.pvp_score) < 5:  # Melhor de 5
                self.start_duel()
            else:
                self.stop_music()
                self.game_state = "menu"

    # --- Sistema de Conquistas ---
    def check_achievements(self):
        """Verifica conquistas ao vencer"""
        if self.arcade_round >= 5 and not self.achievements["round_5"]:
            self.unlock_achievement("round_5")

        if self.arcade_round >= 10 and not self.achievements["round_10"]:
            self.unlock_achievement("round_10")

        if self.arcade_wins >= 10 and not self.achievements["perfect_10"]:
            self.unlock_achievement("perfect_10")

        duel_time = pygame.time.get_ticks() - self.duel_start_time
        if duel_time < 1000 and not self.achievements["fast_winner"]:
            self.unlock_achievement("fast_winner")

        if self.shots_hit == self.shots_fired and self.shots_fired > 0 and not self.achievements["no_miss"]:
            self.unlock_achievement("no_miss")

        if self.arcade_wins == 1 and not self.achievements["first_blood"]:
            self.unlock_achievement("first_blood")

        if self.training_hits >= 50 and not self.achievements["training_master"]:
            self.unlock_achievement("training_master")

    def unlock_achievement(self, name: str):
        """Desbloqueia uma conquista com efeitos"""
        if name in self.achievements and not self.achievements[name]:
            self.achievements[name] = True
            self.save_achievements()
            self.play_sound("achievement")

    def load_achievements(self):
        """Carrega conquistas salvas"""
        try:
            with open("achievements.json", "r") as f:
                self.achievements = json.load(f)
        except:
            self.save_achievements()

    def save_achievements(self):
        """Salva conquistas em arquivo"""
        with open("achievements.json", "w") as f:
            json.dump(self.achievements, f)

    def show_achievements(self):
        """Mostra tela de conquistas"""
        self.game_state = "achievements"
        self.play_music("achievements")

    # --- Renderização ---
    def draw(self):
        """Renderiza todos os elementos"""
        # Fundo
        if self.game_state == "menu":
            screen.blit(self.assets["bg_menu"], (0, 0))
            self.draw_menu()
        elif self.game_state == "achievements":
            screen.blit(self.assets["bg_game"], (0, 0))
            self.draw_achievements()
        elif self.game_state == "training":
            screen.blit(self.assets["bg_game"], (0, 0))
            self.draw_training()
        else:
            screen.blit(self.assets["bg_game"], (0, 0))
            self.draw_game_elements()

        pygame.display.flip()

    def draw_menu(self):
        """Renderiza o menu principal"""
        title = self.font_large.render("DUELO NO OESTE", True, GOLD)
        screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 100))

        # Botões coloridos
        pygame.draw.rect(screen, GREEN, self.controls["arcade"], 0, 10)
        pygame.draw.rect(screen, BLUE, self.controls["pvp"], 0, 10)
        pygame.draw.rect(screen, BROWN, self.controls["training"], 0, 10)
        pygame.draw.rect(screen, GOLD, self.controls["achievements"], 0, 10)

        arcade_text = self.font_medium.render("Arcade", True, WHITE)
        pvp_text = self.font_medium.render("PvP (2 jogadores)", True, WHITE)
        training_text = self.font_medium.render("Modo Treino", True, WHITE)
        achievements_text = self.font_medium.render("Conquistas", True, WHITE)

        screen.blit(arcade_text, (self.controls["arcade"].centerx - arcade_text.get_width()//2, 
                                 self.controls["arcade"].centery - arcade_text.get_height()//2))
        screen.blit(pvp_text, (self.controls["pvp"].centerx - pvp_text.get_width()//2, 
                               self.controls["pvp"].centery - pvp_text.get_height()//2))
        screen.blit(training_text, (self.controls["training"].centerx - training_text.get_width()//2, 
                                   self.controls["training"].centery - training_text.get_height()//2))
        screen.blit(achievements_text, (self.controls["achievements"].centerx - achievements_text.get_width()//2, 
                                       self.controls["achievements"].centery - achievements_text.get_height()//2))

    def draw_game_elements(self):
        """Renderiza elementos do jogo"""
        # Personagens
        screen.blit(self.assets["player1"][self.player1_state], self.player1_pos)
        screen.blit(self.assets["player2"][self.player2_state], self.player2_pos)

        # Balas
        for bullet in self.bullets:
            screen.blit(self.assets["bullet"], (bullet["x"], bullet["y"]))

        # Interface
        if self.game_state == "countdown":
            self.draw_countdown()
        elif self.game_state == "result":
            self.draw_result()

        # Controles mobile
        if self.game_state == "duel":
            self.draw_touch_controls()

        # Placar no modo PvP
        if self.game_mode == "pvp" and self.game_state == "duel":
            score_text = self.font_medium.render(f"{self.pvp_score[0]} - {self.pvp_score[1]}", True, WHITE)
            screen.blit(score_text, (SCREEN_WIDTH//2 - score_text.get_width()//2, 50))

    def draw_training(self):
        """Renderiza o modo treino"""
        # Personagem
        screen.blit(self.assets["player1"]["idle"], self.player1_pos)

        # Balas
        for bullet in self.bullets:
            screen.blit(self.assets["bullet"], (bullet["x"], bullet["y"]))

        # Alvo
        pygame.draw.rect(screen, RED, self.controls["training_target"], 0, 10)
        target_text = self.font_small.render("ALVO", True, WHITE)
        screen.blit(target_text, (self.controls["training_target"].centerx - target_text.get_width()//2, 
                                 self.controls["training_target"].centery - target_text.get_height()//2))

        # Estatísticas
        stats_text = self.font_medium.render(f"Acertos: {self.training_hits} | Erros: {self.training_misses}", True, WHITE)
        screen.blit(stats_text, (50, 50))

        # Controle
        s = pygame.Surface((200, 150), pygame.SRCALPHA)
        s.fill((0, 0, 0, 150))
        screen.blit(s, (50, SCREEN_HEIGHT-150))
        shoot_text = self.font_small.render("ATIRAR", True, WHITE)
        screen.blit(shoot_text, (150 - shoot_text.get_width()//2, SCREEN_HEIGHT-90))

        # Instrução
        if self.training_hits < 50:
            hint_text = self.font_small.render("Acerte 50 vezes para desbloquear uma conquista!", True, WHITE)
            screen.blit(hint_text, (SCREEN_WIDTH//2 - hint_text.get_width()//2, SCREEN_HEIGHT - 50))

    def draw_countdown(self):
        """Renderiza contagem regressiva"""
        if self.countdown > 0:
            text = self.font_large.render(str(self.countdown), True, WHITE)
            screen.blit(text, (SCREEN_WIDTH//2 - text.get_width()//2, SCREEN_HEIGHT//3))
        else:
            text = self.font_large.render("ATIRE!", True, RED)
            screen.blit(text, (SCREEN_WIDTH//2 - text.get_width()//2, SCREEN_HEIGHT//3))

    def draw_result(self):
        """Renderiza tela de resultado"""
        # Fundo escurecido
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill(BLACK_ALPHA)
        screen.blit(overlay, (0, 0))

        # Textos
        if self.winner == 1:
            title = self.font_large.render("VITÓRIA!", True, GOLD)
        else:
            title = self.font_large.render("DERROTA!", True, RED)
        screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, SCREEN_HEIGHT//3))

        if self.game_mode == "arcade":
            round_text = self.font_medium.render(f"Rodada: {self.arcade_round}/{MAX_ROUNDS}", True, WHITE)
            screen.blit(round_text, (SCREEN_WIDTH//2 - round_text.get_width()//2, SCREEN_HEIGHT//2))
        elif self.game_mode == "pvp":
            score_text = self.font_medium.render(f"Placar: {self.pvp_score[0]} - {self.pvp_score[1]}", True, WHITE)
            screen.blit(score_text, (SCREEN_WIDTH//2 - score_text.get_width()//2, SCREEN_HEIGHT//2))

        hint = self.font_small.render("Toque para continuar", True, WHITE)
        screen.blit(hint, (SCREEN_WIDTH//2 - hint.get_width()//2, SCREEN_HEIGHT - 150))

    def draw_touch_controls(self):
        """Renderiza controles touch"""
        # Botões de tiro semi-transparentes
        s = pygame.Surface((200, 150), pygame.SRCALPHA)
        s.fill((0, 0, 0, 150))
        screen.blit(s, (50, SCREEN_HEIGHT-150))
        screen.blit(s, (SCREEN_WIDTH-250, SCREEN_HEIGHT-150))

        shoot_text = self.font_small.render("ATIRAR", True, WHITE)
        screen.blit(shoot_text, (150 - shoot_text.get_width()//2, SCREEN_HEIGHT-90))
        screen.blit(shoot_text, (SCREEN_WIDTH-150 - shoot_text.get_width()//2, SCREEN_HEIGHT-90))

    def draw_achievements(self):
        """Renderiza tela de conquistas"""
        # Fundo escurecido
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill(BLACK_ALPHA)
        screen.blit(overlay, (0, 0))

        title = self.font_large.render("CONQUISTAS", True, GOLD)
        screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 50))

        achievements = [
            ("Primeiro Sangue", "first_blood", "Primeira vitória"),
            ("Rodada 5", "round_5", "Chegue à 5ª rodada"),
            ("Rodada 10", "round_10", "Complete todas as rodadas"),
            ("Gatilho Rápido", "fast_winner", "Vença em <1 segundo"),
            ("Precisão", "no_miss", "Vença sem errar tiros"),
            ("Perfeição", "perfect_10", "Vença todas as rodadas"),
            ("Campeão PvP", "pvp_winner", "Vença uma partida PvP"),
            ("Mestre do Treino", "training_master", "Acerte 50 vezes no treino")
        ]

        for i, (name, key, desc) in enumerate(achievements):
            y_pos = 150 + i * 70
            color = GREEN if self.achievements[key] else RED

            # Ícone
            pygame.draw.circle(screen, color, (80, y_pos + 25), 20)

            # Textos
            name_text = self.font_medium.render(name, True, color)
            desc_text = self.font_small.render(desc, True, WHITE)

            screen.blit(name_text, (130, y_pos))
            screen.blit(desc_text, (130, y_pos + 35))

        # Instrução para voltar
        back_text = self.font_small.render("Toque para voltar", True, WHITE)
        screen.blit(back_text, (SCREEN_WIDTH//2 - back_text.get_width()//2, SCREEN_HEIGHT - 50))

    # --- Controles ---
    def handle_events(self):
        """Processa todos os eventos"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

            # Controles touch
            if event.type == pygame.FINGERDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                pos = (event.x * SCREEN_WIDTH, event.y * SCREEN_HEIGHT) if hasattr(event, 'x') else pygame.mouse.get_pos()
                self.handle_touch(pos)

            # Teclado
            if event.type == pygame.KEYDOWN:
                if self.game_state == "menu":
                    if event.key == pygame.K_1:
                        self.start_arcade_mode()
                    elif event.key == pygame.K_2:
                        self.start_pvp_mode()
                    elif event.key == pygame.K_3:
                        self.start_training_mode()
                    elif event.key == pygame.K_4:
                        self.show_achievements()
                    elif event.key == pygame.K_ESCAPE:
                        return False

                elif self.game_state == "duel":
                    if event.key == pygame.K_f:
                        self.fire_shot(1)
                    elif event.key == pygame.K_j:
                        self.fire_shot(2)

                elif self.game_state == "training" and event.key == pygame.K_SPACE:
                    self.fire_training_shot()

                elif self.game_state == "result" and event.key == pygame.K_RETURN:
                    self.handle_round_transition()

                elif self.game_state == "achievements" and event.key == pygame.K_ESCAPE:
                    self.game_state = "menu"
                    self.stop_music()

        return True

    def handle_touch(self, pos):
        """Processa toques na tela"""
        if self.game_state == "menu":
            if self.controls["arcade"].collidepoint(pos):
                self.start_arcade_mode()
            elif self.controls["pvp"].collidepoint(pos):
                self.start_pvp_mode()
            elif self.controls["training"].collidepoint(pos):
                self.start_training_mode()
            elif self.controls["achievements"].collidepoint(pos):
                self.show_achievements()

        elif self.game_state == "duel":
            if self.controls["shoot_left"].collidepoint(pos):
                self.fire_shot(1)
            elif self.controls["shoot_right"].collidepoint(pos):
                self.fire_shot(2)

        elif self.game_state == "training":
            if self.controls["shoot_left"].collidepoint(pos):
                self.fire_training_shot()

        elif self.game_state == "result":
            self.handle_round_transition()  # Toque em qualquer lugar para continuar

        elif self.game_state == "achievements":
            self.game_state = "menu"  # Toque em qualquer lugar para voltar
            self.stop_music()

def main():
    """Ponto de entrada principal"""
    game = Game()
    running = True

    while running:
        running = game.handle_events()
        game.update()
        game.draw()
        clock.tick(FPS)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()